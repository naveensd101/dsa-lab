#include<stdio.h>
int main() {
	printf("99\n");
	return 0;
}
