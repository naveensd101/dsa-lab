#include<stdio.h>
int main() {
	printf("99");
	return 0;
}
